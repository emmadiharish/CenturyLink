/*
    This service should be changed later because this was build under assumotion that one product can only belong to one option group.
    componentId should be used instead of productId for parentId to create hierarchy or rendering sub option groups.
*/
(function() {
    angular.module('APTPS_ngCPQ').service('OptionGroupDataService', OptionGroupDataService); 
    OptionGroupDataService.$inject = ['$q', '$log', 'BaseService', 'BaseConfigService', 'RemoteService', 'MessageService', 'ProductDataService', 'OptionGroupCache'];
    function OptionGroupDataService($q, $log, BaseService, BaseConfigService, RemoteService, MessageService, ProductDataService, OptionGroupCache) {
        var service = this;
        
        var Selectedoptionproduct = {};// to render option attributes.
        var currentproductoptiongroups = {};
        var rerenderHierarchy = false;// to render option group hierarchy whenever product is added/removed from option groups.
        var slectedOptionGroupProdId;// to render option groups based on group hierarchy traversal.
        var showConfigureOptionstab = true;// used to hide the 'Configure Options' tab if no option group exists.
        
        // option group methods.
        service.getallOptionGroups = getallOptionGroups;
        service.getOptionGroup = getOptionGroup;
        service.getSelectedoptionproduct = getSelectedoptionproduct;
        service.setSelectedoptionproduct = setSelectedoptionproduct;
        service.getcurrentproductoptiongroups = getcurrentproductoptiongroups;
        service.getrerenderHierarchy = getrerenderHierarchy;
        service.setrerenderHierarchy = setrerenderHierarchy;
        service.getslectedOptionGroupProdId = getslectedOptionGroupProdId;
        service.setslectedOptionGroupProdId = setslectedOptionGroupProdId;
        
        function getallOptionGroups(){
            return OptionGroupCache.getOptionGroups();
        }
        
        /* recurvive function to query all option groups on page load
           will load upto 5 levels */
        function getOptionGroups(productIds, deferred) {
            if (!deferred) {
                deferred = $q.defer();
            }

            var cartId = BaseConfigService.cartId;
            var lineNumber = BaseConfigService.lineItem.lineNumber;
            var requestPromise = RemoteService.getProductoptiongroupsData(productIds, cartId, lineNumber);
            var currentSubBundleLevel = 0;
            var maxSubBundleLevel = 5;// constant to limit the option group recursive remote call.
            requestPromise.then(function(response) {
                OptionGroupCache.initializeOptionGroups(response);
                var cachedOptionGroups = OptionGroupCache.getOptionGroups();
                var alloptionProductIds_hasOptions = OptionGroupCache.getProductIdsofBundles();
                var prodIds_filtered = _.difference(alloptionProductIds_hasOptions, _.keys(cachedOptionGroups)); 
                if (prodIds_filtered.length > 0
                    && currentSubBundleLevel < maxSubBundleLevel) {
                    getOptionGroups(prodIds_filtered, deferred);    
                }
                else{
                    deferred.resolve();
                    BaseService.setOptionGroupLoadComplete();
                    return deferred.promise;
                }
            });

            deferred.notify();
            return deferred.promise;
        }

        function getOptionGroup(productId) {
            var cachedOptionGroups = OptionGroupCache.getOptionGroups();
            if (OptionGroupCache.isValid
                && _.has(cachedOptionGroups, productId)){
                setcurrentproductoptiongroups(cachedOptionGroups[productId]);
                return $q.when(true);
            }

            var bundleproductIds = [];
            bundleproductIds.push(productId);
            return getOptionGroups(bundleproductIds).then(function(response){
                cachedOptionGroups = OptionGroupCache.getOptionGroups();
                setcurrentproductoptiongroups(cachedOptionGroups[productId]);
                return true;
            })
        }

        function getSelectedoptionproduct() {
            return Selectedoptionproduct;
        }

        function setSelectedoptionproduct(optionComponent) {
            Selectedoptionproduct = {'productId':optionComponent.productId, 'productName': optionComponent.productName, 'componentId':optionComponent.componentId};
        }

        function getcurrentproductoptiongroups(){
            return currentproductoptiongroups;
        }

        function setcurrentproductoptiongroups(result){
            currentproductoptiongroups = result;
        }

        // util method. a: option groups, b: field name to access product components, c:field to identify if product is bundle or not, d: field name to access product Id within product component.
        function getAllBundleProductsinCurrentOptiongroups(a, b, c, d){
            // return a list of bundle product Id's. based on flag provided.
            var res = [];
            _.each(a, function (g) {
                res.push.apply(res, _.pluck(_.filter(g[b], function(h){
                    return h[c];
                }), d));
            });
            return res;
        }

        function getrerenderHierarchy(){
            return rerenderHierarchy;
        }

        function setrerenderHierarchy(val){
            rerenderHierarchy = val;
        }

        function getslectedOptionGroupProdId(){
            return slectedOptionGroupProdId;
        }

        function setslectedOptionGroupProdId(val){
            slectedOptionGroupProdId = val;
        }
    }
})();